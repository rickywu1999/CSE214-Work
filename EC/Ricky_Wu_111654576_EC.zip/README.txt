To run the code:
1.make
2.make 1

To run your own test cases:
1.make
2.make WeightedGraph <textfile name>

To clean:
1.make clean