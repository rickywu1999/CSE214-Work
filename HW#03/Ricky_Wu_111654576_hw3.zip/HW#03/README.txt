Note: prompts did not specify how to arrange the input files so I used the same formatting as HW#02 where the first line is the number of test cases

To run the code for each question:
1.make
2.make <question number>
For example, for Q1, type �make 1�

To run your own test cases:
1.make
2.make <program name> <textfile name>
Program names for each question:
Q1.BSTConverter
Q2.ConcertSeats

To clean:
1.make clean