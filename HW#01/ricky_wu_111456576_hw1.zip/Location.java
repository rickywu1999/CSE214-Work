
public class Location {
	int x;
	int y;
	
	public Location(int a, int b) {
		x = a;
		y = b;
	}
}
