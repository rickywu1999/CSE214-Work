Compile:
make

Run:
make run

Clean:
make clean