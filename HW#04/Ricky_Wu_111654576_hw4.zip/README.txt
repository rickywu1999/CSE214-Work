To run the code for each question:
1.make
2.make <question number>
For example, for Q1, type �make 1�

To run your own test cases:
1.make
2.make <program name> <textfile name>
Program names for each question:
Q1.findSum
Q2.tripleSum

To clean:
1.make clean